To run the simulation code, pleas do as following:
- If you already open some Rhino windows, close all of them.
- Open the Rhino file first (Simulation of collagen in liver lobules.3dm).
- In the window of Rhino, find the green 'Grasshopper' plugin button in the 'Standard' tab.
- Open the gh file (Simulation of collagen in liver lobules.gh) in the grasshopper plugin.
- The file could be frozen for several minutes due to the calculation capacity of your device. The file needs to recalculate the location of the fibers.
- To run a crude simulation, click the kangaroo block with the middle button on your mouse and choose to make it visible. Click the toggle of Kangaroo to start the simulation.
- To run a more precise simulation, change the size of the area to be simulated to 70 and the point number to 40000. This could take several hours or even longer due to the calculation capacity of your device.